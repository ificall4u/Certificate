package com.nysc.certgen

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        configureWebView()

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun configureWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.addJavascriptInterface(MainBridge(this), "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                /*
                 * Inject the Android-aware generate() override here in onPageFinished,
                 * AFTER the page is fully loaded. This guarantees the Android bridge
                 * object exists in the JS context and that window.templates (changed
                 * from const → var in index.html) is accessible on window.
                 *
                 * The inline check `typeof Android !== 'undefined'` in index.html
                 * acts as a first pass; this injection is the reliable second pass.
                 */
                val js = """
                    (function() {
                        if (typeof Android === 'undefined') return;

                        window.generate = function() {
                            var name         = (document.getElementById('name').value         || '').trim();
                            var code         = (document.getElementById('code').value         || '').trim();
                            var category     =  document.getElementById('category').value;
                            var customYear   = (document.getElementById('serviceYear').value  || '2025/2026');
                            var awardDateRaw =  document.getElementById('awardDate').value;
                            var genderEl     =  document.getElementById('genderSelect');
                            var gender       =  genderEl ? genderEl.value : 'male';
                            var role         = (category === 'Executive')
                                                  ? document.getElementById('role').value
                                                  : 'Member';

                            if (!name) { alert('Please enter a Full Name.');  return; }
                            if (!code) { alert('Please enter a State Code.'); return; }

                            var tmpl = window.templates ? window.templates[role] : null;
                            if (!tmpl) { alert('Template not found for: ' + role); return; }

                            // same transforms as original generate()
                            tmpl = tmpl.replace(/2025\/2026/g, customYear);
                            if (typeof applyGenderPronouns === 'function')
                                tmpl = applyGenderPronouns(tmpl, gender);

                            // inject name & code directly into the HTML string
                            tmpl = tmpl.replace('id="cert-name"></span>',
                                                'id="cert-name">' + name + '</span>');
                            tmpl = tmpl.replace('id="cert-code"></span>',
                                                'id="cert-code">' + code + '</span>');

                            // inject award date after the cert-body paragraph
                            if (awardDateRaw && typeof formatDate === 'function') {
                                var fd = formatDate(awardDateRaw);
                                var dateHtml =
                                    '<div style="margin-top:25px;text-align:center;">' +
                                    '<div style="width:40%;height:2px;margin:10px auto;' +
                                    'background:linear-gradient(to right,#fff,#c5a059,#fff);"></div>' +
                                    '<div style="font-family:Playfair Display,serif;font-size:14px;' +
                                    'color:#333;font-style:italic;">Awarded on this ' + fd + '</div>' +
                                    '<div style="font-size:8px;color:#777;margin-top:12px;' +
                                    'text-transform:uppercase;letter-spacing:2px;">' +
                                    'Verified Certificate of Service - Official NYSC EPSG Documentation' +
                                    '</div></div>';
                                var cbIdx = tmpl.indexOf('class="cert-body"');
                                if (cbIdx > -1) {
                                    var pEnd = tmpl.indexOf('</p>', cbIdx);
                                    if (pEnd > -1)
                                        tmpl = tmpl.slice(0, pEnd + 4) + dateHtml + tmpl.slice(pEnd + 4);
                                }
                            }

                            Android.openCertificate(tmpl);
                        };
                    })();
                """.trimIndent()

                view.evaluateJavascript(js, null)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }
}
