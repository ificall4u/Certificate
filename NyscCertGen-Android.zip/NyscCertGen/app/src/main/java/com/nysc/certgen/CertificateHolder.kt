package com.nysc.certgen

/**
 * A simple in-memory store for the generated certificate HTML.
 * Using an object (singleton) avoids Intent size limits that arise
 * when passing large HTML strings as Bundle extras.
 */
object CertificateHolder {
    var html: String = ""
}
