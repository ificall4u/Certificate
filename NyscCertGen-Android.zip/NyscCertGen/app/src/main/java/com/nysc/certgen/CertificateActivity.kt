package com.nysc.certgen

import android.os.Bundle
import android.print.PrintManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class CertificateActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_certificate)

        webView = findViewById(R.id.certWebView)
        configureWebView()

        // Native print button — calls PrintManager directly, no JS bridge required
        val btnPrint: Button = findViewById(R.id.btnPrint)
        btnPrint.setOnClickListener {
            printCurrentPage()
        }

        val html = CertificateHolder.html
        if (html.isNotEmpty()) {
            /*
             * Hide the HTML's own print button so it doesn't clash with
             * our native button, then load the certificate.
             */
            val patched = html.replace(
                "class=\"print-btn\"",
                "class=\"print-btn\" style=\"display:none!important;\""
            )

            webView.loadDataWithBaseURL(
                "https://nysc.certgen.local/",
                patched,
                "text/html",
                "UTF-8",
                null
            )
        } else {
            finish()
        }
    }

    /**
     * Triggers Android's native system print dialog.
     * Works with Save as PDF, wireless printers, Bluetooth, etc.
     * Called directly from the native Button — no JavaScript involved.
     */
    private fun printCurrentPage() {
        val printManager = getSystemService(PRINT_SERVICE) as PrintManager
        val printAdapter = webView.createPrintDocumentAdapter("NYSC_Certificate")
        printManager.print("NYSC EPSG Certificate", printAdapter, null)
    }

    private fun configureWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                // Extra: hide the HTML print button via JS too, in case
                // the class replace didn't match (different template variant)
                view.evaluateJavascript(
                    "document.querySelectorAll('.print-btn').forEach(function(b){ b.style.display='none'; });",
                    null
                )
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }
}
