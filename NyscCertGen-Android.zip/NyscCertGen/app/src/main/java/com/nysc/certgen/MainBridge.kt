package com.nysc.certgen

import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface

/**
 * JavaScript bridge exposed as "Android" in the main form WebView.
 *
 * The generate() function in index.html calls window.open('', '_blank')
 * and writes the full certificate HTML into the new window.
 * We intercept that with an overridden window.open (injected via evaluateJavascript)
 * so that document.close() calls Android.openCertificate(html) instead.
 */
class MainBridge(private val context: Context) {

    @JavascriptInterface
    fun openCertificate(html: String) {
        // Store HTML in the singleton (avoids TransactionTooLargeException)
        CertificateHolder.html = html

        val intent = Intent(context, CertificateActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
