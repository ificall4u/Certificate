package com.nysc.certgen

import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * JavaScript bridge exposed as "AndroidPrint".
 *
 * When the certificate page calls window.print() we intercept it here
 * and forward to Android's native PrintManager, which opens the system
 * print dialog (supports Save as PDF, wireless printing, etc.).
 */
class PrintBridge(private val webView: WebView) {

    @JavascriptInterface
    fun print() {
        // PrintManager must be called on the UI thread.
        webView.post {
            val context = webView.context
            val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE)
                    as PrintManager
            val printAdapter = webView.createPrintDocumentAdapter("NYSC_Certificate")
            printManager.print(
                "NYSC EPSG Certificate",
                printAdapter,
                null          // Use default print attributes (letter/A4, etc.)
            )
        }
    }
}
