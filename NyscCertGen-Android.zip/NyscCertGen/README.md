# NYSC EPSG Certificate Generator — Android App

A native Android WebView wrapper for the NYSC EPSG Certificate Generator HTML tool.

## What it does

- Loads the certificate generator form locally (no server needed)
- When you tap **"Generate & View Certificate"**, a new screen opens with the rendered certificate
- Tapping **"Print Certificate"** opens the Android system print dialog (supports **Save as PDF**, wireless printers, Bluetooth printers, etc.)

## How to build

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 11 or 17 (bundled with Android Studio)
- Android SDK API 34 (install via Android Studio SDK Manager)

### Steps

1. **Open the project in Android Studio**
   - File → Open → select this `NyscCertGen/` folder
   - Android Studio will download Gradle and all dependencies automatically

2. **Connect a device or start an emulator**
   - Enable USB Debugging on your physical Android phone (Settings → Developer Options)
   - Or use the AVD Manager to create a virtual device

3. **Run the app**
   - Click the green ▶ Run button, or press `Shift+F10`
   - The APK is installed and launched on your device/emulator

4. **Build a release APK** (to share or sideload)
   - Build → Generate Signed Bundle/APK → APK
   - Follow the signing wizard (create a new keystore if you don't have one)
   - The signed APK will be at `app/release/app-release.apk`

### Optional: command-line build

```bash
# On macOS/Linux
./gradlew assembleDebug

# On Windows
gradlew.bat assembleDebug
```

Output APK: `app/build/outputs/apk/debug/app-debug.apk`

---

## Project structure

```
NyscCertGen/
├── app/src/main/
│   ├── assets/
│   │   └── index.html              ← Your complete HTML file (loaded locally)
│   ├── java/com/nysc/certgen/
│   │   ├── MainActivity.kt         ← Hosts the form WebView; intercepts window.open()
│   │   ├── CertificateActivity.kt  ← Displays the generated certificate
│   │   ├── MainBridge.kt           ← JS→Android bridge: receives certificate HTML
│   │   ├── PrintBridge.kt          ← JS→Android bridge: triggers system print dialog
│   │   └── CertificateHolder.kt    ← In-memory HTML store (avoids Intent size limits)
│   └── AndroidManifest.xml
```

## How the print bridge works

The certificate template contains:
```html
<button onclick="window.print()">Print Certificate</button>
```

When `CertificateActivity` finishes loading the HTML, it injects this JavaScript:
```javascript
window.print = function() { AndroidPrint.print(); };
```

`AndroidPrint` is a Kotlin object (`PrintBridge`) that calls Android's `PrintManager`, which opens the native system print dialog. The user can then choose any installed printer or **Save as PDF**.

## Notes

- The app requires an internet connection to load Google Fonts and certificate logos (served from external URLs in the HTML)
- Minimum Android version: API 24 (Android 7.0 Nougat)
- Target SDK: API 34 (Android 14)
